package com.example.pawfindermy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private Button btnFindVet, btnAddClinic, btnViewFavorites, btnLogout;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        // Optional: Check if user is actually logged in
        if (user == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // 2. Link Views
        btnFindVet = findViewById(R.id.btnFindVet);
        btnAddClinic = findViewById(R.id.btnAddClinic);
        btnViewFavorites = findViewById(R.id.btnViewFavorites); // NEW BUTTON
        btnLogout = findViewById(R.id.btnLogout);

        // 3. Button Action: Find Vet (Map)
        btnFindVet.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MapsActivity.class);
            startActivity(intent);
        });

        // 4. Button Action: Add Clinic / Log Visit
        btnAddClinic.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddClinicActivity.class);
            startActivity(intent);
        });

        // 5. Button Action: View Favorites (NEW)
        btnViewFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
            startActivity(intent);
        });

        // 6. Button Action: Logout
        btnLogout.setOnClickListener(v -> {
            // Sign out from Firebase
            mAuth.signOut();



            Toast.makeText(MainActivity.this, "Signed Out", Toast.LENGTH_SHORT).show();

            // Return to Login Activity
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            // Clear the back stack so user can't press "Back" to return to Main
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
        // inside onCreate
        Button btnAboutUs = findViewById(R.id.btnAboutUs);

        btnAboutUs.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AboutUsActivity.class);
            startActivity(intent);
        });
    }
}