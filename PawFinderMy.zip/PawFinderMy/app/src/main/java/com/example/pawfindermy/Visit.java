package com.example.pawfindermy;

public class Visit {
    public String id;
    public String clinicName; // Was 'name'
    public String notes;      // Was 'phone'
    public String timestamp;  // NEW: To track when the visit happened
    public double latitude;
    public double longitude;
    public String imageBase64;

    // Empty constructor is REQUIRED for Firebase to read data back
    public Visit() { }

    public Visit(String id, String clinicName, String notes, String timestamp, double latitude, double longitude, String imageBase64) {
        this.id = id;
        this.clinicName = clinicName;
        this.notes = notes;
        this.timestamp = timestamp;
        this.latitude = latitude;
        this.longitude = longitude;
        this.imageBase64 = imageBase64;
    }
}